[Github-flavored Markdown](https://github.com/LSalimene/PoissonFuncaoCorrente)

PoissonFuncaoCorrente

Esse pacote utiliza métodos númericos iterativos para resolver a equação que relaciona a Função Corrente com a vorticidade. 

Use o gerenciador de pacotes pip para instalar o pacote PoissonFuncaoCorrente com o comando:

pip install PoissonFuncaoCorrente

O pacote PoissonFuncaoCorrente é liberado sob a licença [MIT].